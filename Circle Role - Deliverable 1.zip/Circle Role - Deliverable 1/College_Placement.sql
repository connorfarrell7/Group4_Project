-- Creating student_info table
Create table student_info (
    ID int not null,
    Age int not null,
    Gender varchar(10) not null,
    Stream varchar (40) not null,
    primary key (ID)
);

-- Checking import
Select * From student_info;

-- Creating placement_predictors table
Create table placement_predictors (
    ID int not null,
    Internships int not null,
    CGPA int not null,
    Hostel int not null,
    HistoryOfBacklogs int not null,
    PlacedOrNot int not null,
    foreign key (ID) references student_info.ID
    primary key (ID)
);

-- Checking import
Select * From placement_predictors;

-- Joining the two tables 
Select student_info.ID,
    student_info.Age,
    student_info.Gender,
    student_info.Stream,
    placement_predictors.CGPA,
    placement_predictors.Hostel,
    placement_predictors.HistoryOfBacklogs,
    placement_predictors.PlacedOrNot,
left join placement_predictors
ON student_info.ID = placement_predictors.ID